package com.example.novel;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.TextView;

public class DetailActivity extends AppCompatActivity {
    TextView TvnamaBuku;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail);
        TvnamaBuku=findViewById(R.id.tv_Nama);
        TvnamaBuku.setText(getIntent().getStringExtra("nama"));
        TvnamaBuku=findViewById(R.id.tv_deskripsi);
        TvnamaBuku.setText(getIntent().getStringExtra("deskripsi"));
        TvnamaBuku=findViewById(R.id.tv_harga);
        TvnamaBuku.setText(getIntent().getStringExtra("harga"));
    }
}